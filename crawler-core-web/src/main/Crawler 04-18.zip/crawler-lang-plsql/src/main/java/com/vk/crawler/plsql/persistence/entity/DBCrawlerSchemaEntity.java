package com.vk.crawler.plsql.persistence.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import com.vk.crawler.core.model.DataModel;
import com.vk.crawler.core.util.StringUtils;

@Entity
@Table(name="VI_DB_CRAWLER_SCHEMAS")
@TableGenerator(name = "schema_entity", table = "SEQUENCE", pkColumnName = "SEQ_NAME", pkColumnValue = "VI_DB_CRAWLER_SCHEMAS", valueColumnName = "SEQ_COUNT", allocationSize = 1)
@NamedQuery(name="DBCrawlerSchemaEntity.findAll", query="SELECT d FROM DBCrawlerSchemaEntity d")
public class DBCrawlerSchemaEntity implements DataModel {
  
  private static final long serialVersionUID = 1L;

  @Id
  @GeneratedValue(strategy=GenerationType.TABLE, generator = "schema_entity")
  private Integer id;

  @Column(name="DB_ID")
  private Integer dbId;

  private String name;
  
  @Lob
  private String description;

  @Column(name="TRIGGER_ID")
  private Integer triggerId;

  public Integer getId() {
    return this.id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  public Integer getDbId() {
    return this.dbId;
  }

  public void setDbId(Integer dbId) {
    this.dbId = dbId;
  }

  public String getDescription() {
    return this.description;
  }

  public void setDescription(String description) {
    this.description = description;
  }

  public String getName() {
    return this.name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Integer getTriggerId() {
    return this.triggerId;
  }

  public void setTriggerId(Integer triggerId) {
    this.triggerId = triggerId;
  }

  public boolean isEmpty() {
    return StringUtils.isEmpty(name);
  }

  public String toString() {
    return "<DBCrawlerSchemaEntity><id>" + id + "</id><dbId>" + dbId + "</dbId><name>" + name + "</name><description>"
        + description + "</description><triggerId>" + triggerId + "</triggerId></DBCrawlerSchemaEntity>";
  }
}